// A simple in-memory storage for demo purposes
let users = [];

module.exports = { users };
